Depy 2016 Talk: Pre-Modeling: Data Preprocessing and Feature Exploration in Python

Author: April Chen, Data Scientist at Civis Analytics

This repo contains several files:

- Notebook:
  - DePy_Talk.ipynb
- Data:
  - adult.csv
- Images:
  - interactions.jpg
  - outliers.jpg
  - pca.jpg
  - tukeyiqr.jpg
